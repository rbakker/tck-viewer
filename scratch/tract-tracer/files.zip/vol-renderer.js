// ── vol-renderer.js ───────────────────────────────────────
// WebGL2 3D-texture volume renderer.
// - Uploads NIfTI data as a single TEXTURE_3D (R16F or R8)
// - Renders oblique slices via a fullscreen quad + fragment shader
// - One shared GL context and texture; multiple slice canvases each
//   get their own framebuffer-less render pass via transferControlToOffscreen
//   or direct canvas rendering.
//
// Usage:
//   const vr = new VolRenderer();
//   await vr.upload(nii);               // upload 3D texture
//   vr.renderSlice(canvas, params);     // draw one slice
//   vr.setRotation(pitch, yaw, roll);   // update oblique rotation

import { eulerToMat3, mat3mulVec, rasToVox } from './affine.js';

// ── Shaders ───────────────────────────────────────────────

const VS = `#version 300 es
in vec2 a_pos;          // fullscreen quad [-1,1]
out vec2 v_uv;          // [0,1] across canvas
void main(){
  v_uv = a_pos*0.5+0.5;
  gl_Position = vec4(a_pos,0,1);
}`;

// Slice shader: samples 3D texture along an oblique plane.
// Uniforms:
//   u_vol      — TEXTURE_3D sampler
//   u_origin   — 3D texture-space origin of the slice (bottom-left corner)
//   u_axisU    — texture-space step per pixel in U direction
//   u_axisV    — texture-space step per pixel in V direction
//   u_window   — vec2(min, range) for windowing
//   u_crosshair— vec2 normalised crosshair position [0,1]
//   u_chColor  — vec3 crosshair color
const FS_SLICE = `#version 300 es
precision highp float;
precision highp sampler3D;
uniform sampler3D u_vol;
uniform vec3  u_origin;
uniform vec3  u_axisU;
uniform vec3  u_axisV;
uniform vec2  u_window;   // (wmin, wrange)
uniform vec2  u_crosshair;
uniform vec3  u_chColor;
in  vec2 v_uv;
out vec4 fragColor;
void main(){
  vec3 tc = u_origin + v_uv.x*u_axisU + v_uv.y*u_axisV;
  // out-of-volume → black
  if(any(lessThan(tc,vec3(0.0)))||any(greaterThan(tc,vec3(1.0)))){
    fragColor=vec4(0,0,0,1); return;
  }
  float raw = texture(u_vol, tc).r;
  float v   = clamp((raw - u_window.x)/u_window.y, 0.0, 1.0);
  vec3 col  = vec3(v);

  // crosshair
  vec2 d = abs(v_uv - u_crosshair);
  float ch = step(d.x,0.0015)*step(0.02,d.y) + step(d.y,0.0015)*step(0.02,d.x);
  col = mix(col, u_chColor, ch*0.85);

  fragColor = vec4(col,1);
}`;

// ── VolRenderer ───────────────────────────────────────────

export class VolRenderer {
  constructor() {
    // One hidden GL canvas shared across all slice renders
    this._glCanvas = document.createElement('canvas');
    this._glCanvas.width  = 1;
    this._glCanvas.height = 1;
    const gl = this._glCanvas.getContext('webgl2', {preserveDrawingBuffer:true});
    if (!gl) throw 'WebGL2 not available';
    this.gl = gl;
    this._texture = null;
    this._nii = null;
    this._prog = this._buildProgram(VS, FS_SLICE);
    this._quad = this._buildQuad();
    // rotation matrix (3×3, row-major array of arrays), starts as identity
    this._rot = [[1,0,0],[0,1,0],[0,0,1]];
    // window level: [min, max] in raw data units — set on upload
    this._wmin = 0;
    this._wmax = 1;
    // 2D canvas for blitting results
    this._blitCanvas = document.createElement('canvas');
    this._blitCtx    = this._blitCanvas.getContext('2d');
  }

  // ── Public API ─────────────────────────────────────────

  upload(nii) {
    const gl = this.gl;
    this._nii = nii;

    // Normalise data to Float32 for R32F texture
    // (R16F would save memory but loses precision for Int16 data)
    const n = nii.nx*nii.ny*nii.nz;
    const texData = new Float32Array(n);
    const mn=nii.mn, range=nii.mx-nii.mn || 1;
    for (let i=0;i<n;i++) texData[i]=(nii.data[i]-mn)/range;  // normalise to [0,1]
    this._wmin = 0; this._wmax = 1;  // windowed 0..1 after normalisation

    // Check max 3D texture size
    const maxSz = gl.getParameter(gl.MAX_3D_TEXTURE_SIZE);
    if (nii.nx>maxSz||nii.ny>maxSz||nii.nz>maxSz)
      throw `Volume ${nii.nx}×${nii.ny}×${nii.nz} exceeds MAX_3D_TEXTURE_SIZE=${maxSz}`;

    if (this._texture) gl.deleteTexture(this._texture);
    this._texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_3D, this._texture);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);
    gl.texImage3D(gl.TEXTURE_3D, 0, gl.R32F,
      nii.nx, nii.ny, nii.nz, 0,
      gl.RED, gl.FLOAT, texData);
    gl.bindTexture(gl.TEXTURE_3D, null);
    console.log('3D texture uploaded', nii.nx, nii.ny, nii.nz,
      `~${(n*4/1024/1024).toFixed(0)} MB`);
  }

  setRotation(pitch, yaw, roll) {
    this._rot = eulerToMat3(pitch, yaw, roll);
  }

  setWindow(wmin, wmax) {
    this._wmin = wmin;
    this._wmax = wmax;
  }

  // Render one slice onto a 2D canvas.
  // planeKey: 'sag'|'cor'|'axi'
  // cursor: RAS [x,y,z] in mm
  // chColor: [r,g,b] 0..1 crosshair colour
  renderSlice(canvas2d, planeKey, cursor, chColor) {
    if (!this._texture||!this._nii) return;
    const nii = this._nii;
    const gl  = this.gl;

    const W = canvas2d.width, H = canvas2d.height;
    if (W<=0||H<=0) return;

    // Resize offscreen GL canvas
    this._glCanvas.width  = W;
    this._glCanvas.height = H;
    gl.viewport(0,0,W,H);

    // ── Compute slice plane in texture space ──
    // Voxel coords of cursor
    const [cvx,cvy,cvz] = rasToVox(nii.inv, cursor[0], cursor[1], cursor[2]);

    // For each plane: normal N, and two in-plane axes U,V in voxel space
    // (before rotation). U = column direction, V = row direction (bottom-up).
    let N0, U0, V0;
    if (planeKey==='sag') {
      N0=[1,0,0]; U0=[0,1,0]; V0=[0,0,1];
    } else if (planeKey==='cor') {
      N0=[0,1,0]; U0=[1,0,0]; V0=[0,0,1];
    } else {
      N0=[0,0,1]; U0=[1,0,0]; V0=[0,1,0];
    }

    // Apply rotation (in voxel space)
    const R  = this._rot;
    const N  = mat3mulVec(R, N0);
    const U  = mat3mulVec(R, U0);
    const V  = mat3mulVec(R, V0);

    // Physical extent of slice in mm: use pixdim to compute voxel steps
    // such that the slice covers the full FOV.
    // We want the slice to show ±halfExtent mm from cursor along U and V.
    // halfExtent = max dimension of the volume in that direction.
    const Lx=nii.nx*nii.pixdim[1], Ly=nii.ny*nii.pixdim[2], Lz=nii.nz*nii.pixdim[3];
    const halfExtU = (Math.abs(U[0])*Lx + Math.abs(U[1])*Ly + Math.abs(U[2])*Lz) * 0.5;
    const halfExtV = (Math.abs(V[0])*Lx + Math.abs(V[1])*Ly + Math.abs(V[2])*Lz) * 0.5;

    // Aspect ratio correction: fit the physical extent into the canvas
    // preserving mm aspect ratio (letterbox)
    const physAR = halfExtU / halfExtV;
    const canvAR = W / H;
    let scaleU, scaleV;
    if (canvAR > physAR) {
      // canvas wider than slice → pillarbox: fit height
      scaleV = 1.0;
      scaleU = physAR / canvAR;
    } else {
      scaleU = 1.0;
      scaleV = canvAR / physAR;
    }

    // Convert U,V steps from voxel space to texture space ([0,1]^3)
    // One full U sweep = 2*halfExtU mm → in voxels: 2*halfExtU/pixdim[axis]
    // In texture coords: / nDim
    // axisU_tex = U_vox_normalized * (2*halfExtU_vox / nx,ny,nz)
    // We'll parameterise so that u=0..1 maps to the full slice width.
    const pu = halfExtU / nii.pixdim[1];  // half-extent in voxels along U projected on X
    // Actually easier: convert directly
    // texCoord = voxCoord / [nx,ny,nz]
    // axisU in texture space spans 2*halfExtU voxels along U direction
    function voxToTex(vox) {
      return [vox[0]/nii.nx, vox[1]/nii.ny, vox[2]/nii.nz];
    }

    // Centre of slice in texture space
    const cTex = [(cvx+0.5)/nii.nx, (cvy+0.5)/nii.ny, (cvz+0.5)/nii.nz];

    // Total voxel extent of U and V axes across the slice
    // U spans 2*halfExtU mm → in voxels per axis component
    const uVox = [U[0]*2*halfExtU/nii.pixdim[1], U[1]*2*halfExtU/nii.pixdim[2], U[2]*2*halfExtU/nii.pixdim[3]];
    const vVox = [V[0]*2*halfExtV/nii.pixdim[1], V[1]*2*halfExtV/nii.pixdim[2], V[2]*2*halfExtV/nii.pixdim[3]];

    // Apply canvas scaling for aspect ratio
    const uVoxS = [uVox[0]*scaleU, uVox[1]*scaleU, uVox[2]*scaleU];
    const vVoxS = [vVox[0]*scaleV, vVox[1]*scaleV, vVox[2]*scaleV];

    // origin = centre - 0.5*U - 0.5*V  (in texture space)
    const axisU_tex = [uVoxS[0]/nii.nx, uVoxS[1]/nii.ny, uVoxS[2]/nii.nz];
    const axisV_tex = [vVoxS[0]/nii.nx, vVoxS[1]/nii.ny, vVoxS[2]/nii.nz];
    const origin_tex = [
      cTex[0] - axisU_tex[0]*0.5 - axisV_tex[0]*0.5,
      cTex[1] - axisU_tex[1]*0.5 - axisV_tex[1]*0.5,
      cTex[2] - axisU_tex[2]*0.5 - axisV_tex[2]*0.5,
    ];

    // Crosshair position in UV [0,1] space — always at centre for now
    // (0.5, 0.5) = cursor position
    const chUV = [
      0.5 / scaleU * scaleU,   // simplifies to 0.5
      0.5 / scaleV * scaleV,
    ];

    // ── Draw ──
    gl.useProgram(this._prog);
    gl.clearColor(0,0,0,1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_3D, this._texture);
    gl.uniform1i(gl.getUniformLocation(this._prog,'u_vol'), 0);
    gl.uniform3fv(gl.getUniformLocation(this._prog,'u_origin'), origin_tex);
    gl.uniform3fv(gl.getUniformLocation(this._prog,'u_axisU'),  axisU_tex);
    gl.uniform3fv(gl.getUniformLocation(this._prog,'u_axisV'),  axisV_tex);
    gl.uniform2fv(gl.getUniformLocation(this._prog,'u_window'), [this._wmin, this._wmax-this._wmin]);
    gl.uniform2fv(gl.getUniformLocation(this._prog,'u_crosshair'), [0.5, 0.5]);
    gl.uniform3fv(gl.getUniformLocation(this._prog,'u_chColor'), chColor);

    gl.bindVertexArray(this._quad);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindVertexArray(null);

    // Blit GL canvas → 2D canvas
    const ctx2d = canvas2d.getContext('2d');
    ctx2d.drawImage(this._glCanvas, 0, 0);
  }

  // ── Private helpers ────────────────────────────────────

  _buildProgram(vsrc, fsrc) {
    const gl = this.gl;
    const compile = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
        throw 'Shader error: '+gl.getShaderInfoLog(s);
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, vsrc));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, fsrc));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
      throw 'Program link error: '+gl.getProgramInfoLog(prog);
    return prog;
  }

  _buildQuad() {
    const gl = this.gl;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
      -1,-1,  1,-1,  -1,1,  1,1
    ]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(this._prog, 'a_pos');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    return vao;
  }
}
